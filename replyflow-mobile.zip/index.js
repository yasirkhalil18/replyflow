// Entry point for Hostinger Node.js Application Manager
console.log('[Hostinger Entry] Starting ReplyFlow Node.js Server...');
require('./server.js');
